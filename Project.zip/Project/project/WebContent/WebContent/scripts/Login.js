/**
 * 
 */
function login()
	{
		var userName=document.getElementById("uName").value;
		if(userName==null || userName=="")
		{
			document.getElementById("errorUserName").innerHTML="User Name is Must!!!";
			return false;
		}
		return true;
	}