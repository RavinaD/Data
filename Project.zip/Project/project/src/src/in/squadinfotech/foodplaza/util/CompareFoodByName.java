package in.squadinfotech.foodplaza.util;

import in.squadinfotech.foodplaza.dto.Food;

import java.util.Comparator;

public class CompareFoodByName implements Comparator<Food>
{
	public int compare(Food f1, Food f2) 
	{		
		return f1.getFoodName().compareTo(f2.getFoodName());
	}
}
