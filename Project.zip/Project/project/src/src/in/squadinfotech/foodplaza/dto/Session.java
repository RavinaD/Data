package in.squadinfotech.foodplaza.dto;

import java.util.Map;

public class Session {
	/*private Map<String,String> userSession;

	public Map<String, String> getUserSession() {
		return userSession;
	}

	public void setUserSession(Map<String, String> userSession) {
		this.userSession = userSession;
	}*/
	
	private Map<String,Cart> userSession;

	public Map<String, Cart> getUserSession() {
		return userSession;
	}

	public void setUserSession(Map<String, Cart> userSession) {
		this.userSession = userSession;
	}

	

}
