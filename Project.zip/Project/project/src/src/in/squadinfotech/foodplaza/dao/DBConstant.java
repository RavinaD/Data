package in.squadinfotech.foodplaza.dao;

public interface DBConstant 
{

	 String DB_NAME="CT22";
	 
	/* ********* Food *******/
	 
	 String TABLE_NAME="Food";
	 String TABLE_NAME2="FoodType";
	 String INSERT_FOOD = "INSERT INTO "+DB_NAME+"."+ TABLE_NAME+" VALUES(?,?,?,?,?)";
	 String INSERT_FOOD_TYPE="INSERT INTO "+DB_NAME+"."+ TABLE_NAME2+" VALUES(?,?)";
	// String SELECT_ALL_FOODS = "Select * FROM "+DB_NAME+"."+ TABLE_NAME;
	 String SELECT_ALL_FOODS = "SELECT foodID, foodName, foodTypeName, foodPrice, foodQuantity FROM CT22.Food f INNER JOIN CT22.FoodType ft ON f.foodTypeId_FK =ft.foodTypeId" ;
	 String DELETE_FOOD = "DELETE FROM "+DB_NAME+"."+ TABLE_NAME+" WHERE foodID=?";
	 String GET_FOOD = "SELECT foodID, foodName, foodTypeName, foodPrice, foodQuantity FROM CT22.Food f INNER JOIN CT22.FoodType ft ON f.foodTypeId_FK =ft.foodTypeId WHERE foodID=?" ;
	 String UPDATE_FOOD_BYID = "UPDATE "+DB_NAME+"."+ TABLE_NAME+" SET foodType=?,foodName=?,foodPrice=?,foodQuantity=? WHERE foodID=?";
	 String UPDATE_FOOD = "UPDATE "+DB_NAME+"."+ TABLE_NAME+" SET foodType=?,foodName=?,foodPrice=?,foodQuantity=? WHERE foodID=?";
	 String SEARCH_FOOD_BY_TYPE = "SELECT foodID, foodName, foodTypeName, foodPrice, foodQuantity FROM CT22.Food f INNER JOIN CT22.FoodType ft ON f.foodTypeId_FK =ft.foodTypeId where foodTypeName LIKE ? ORDER BY foodID";
	 
    /* ********* User *******/
	 
	 String TABLE_NAME1="User";
	 String INSERT_USER = "INSERT INTO "+DB_NAME+"."+ TABLE_NAME1+" VALUES(?,?,?,?,?,?,?,?)";
	 String SELECT_ALL_USER = "Select * FROM "+DB_NAME+"."+ TABLE_NAME1;
	 String DELETE_USER = "DELETE FROM "+DB_NAME+"."+ TABLE_NAME1+" WHERE userName=?";
	 String GET_USER = "Select * FROM "+DB_NAME+"."+ TABLE_NAME1+" where userName=?";
	 String UPDATE_USER_BY_NAME = "UPDATE "+DB_NAME+"."+ TABLE_NAME1+" SET password=?, mobileNo=?, emailID=?, admin=?,city=?,pinCode=? WHERE userName=?";
	 String CHANGE_PASSWORD="UPDATE "+DB_NAME+"."+ TABLE_NAME1+" SET password=? WHERE userName=?";
	 String USER_EXIST="SELECT * FROM "+DB_NAME+"."+ TABLE_NAME1+" where userName=? AND password=?";
}
