package in.squadinfotech.foodplaza.dto;

public class Address 
{
	private int pincodeNo;
	private String city;
	public int getPinCode() {
		return pincodeNo;
	}
	public void setPinCode(int pinCode) {
		this.pincodeNo = pinCode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Address [pinCode=" + pincodeNo + ", city=" + city + "]";
	}
	
}
