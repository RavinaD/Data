package in.squadinfotech.foodplaza.dto;

import java.io.Serializable;

public class FoodType implements Serializable 
{
	private int foodTypeID;
	private String foodTypeName;
	
	public int getFoodTypeID() {
		return foodTypeID;
	}
	public void setFoodTypeID(int foodTypeID) {
		this.foodTypeID = foodTypeID;
	}
	public String getFoodTypeName() {
		return foodTypeName;
	}
	public void setFoodTypeName(String foodTypeName) {
		this.foodTypeName = foodTypeName;
	}
	@Override
	public String toString() {
		return foodTypeName;
	}
	
	
}
