package in.squadinfotech.foodplaza.util;

import in.squadinfotech.foodplaza.dto.Food;

import java.util.Comparator;

public class CompareFoodByID implements Comparator<Food>
{

	@Override
	public int compare(Food f1, Food f2) {
		
		return f1.getFoodID()-f2.getFoodID();
	}

}
