package in.squadinfotech.foodplaza.controller;

import in.squadinfotech.foodplaza.dao.FoodDao;
import in.squadinfotech.foodplaza.dao.jdbc.impl.FoodDaoImpl;
import in.squadinfotech.foodplaza.dto.Food;
import in.squadinfotech.foodplaza.exception.FoodNotFoundException;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

public class FoodsServlet extends HttpServlet {
	

	private static final long serialVersionUID = 1L;

	@Override
	public void init() throws ServletException {

	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		resp.setContentType("text/html");
		
		HttpSession session = req.getSession(false);
		String operation = req.getParameter("operation");
		
		if (session != null) 

		{
			if (operation != null && operation.equals("getFoodByType"))
			{
				
				FoodDao fooddao = new FoodDaoImpl();
				String foodType=req.getParameter("foodType");
				
				List<Food> listOfFoods = fooddao.searchFoodsByType(foodType);
				System.out.println("RAviiiiiiiiiiiiiiiii");
			/*	if (listOfFoods != null || listOfFoods.size() > 0)
				{*/
					System.out.println(listOfFoods);		
					req.setAttribute("listOfFoods", listOfFoods);
					Gson gson=new Gson();
					resp.setContentType("application/json");
					PrintWriter w=resp.getWriter();
					w.print(gson.toJson(listOfFoods));	
					w.flush();
					w.close();
					
				
			
			}
			
			if (operation != null && operation.equals("getAllFoods"))
			{
				
				FoodDao fooddao = new FoodDaoImpl();
				List<Food> listOfFoods = fooddao.getAllFoods();
				if (listOfFoods != null || listOfFoods.size() > 0)
				{
					System.out.println(listOfFoods);
					session.setAttribute("list", listOfFoods);
					RequestDispatcher rd= req.getRequestDispatcher("Foods.jsp");
					rd.include(req, resp);
					//resp.sendRedirect("Foods.jsp");

				}
				
				
				
			}
			if(operation!=null && operation.equals("showDetails"))
			{
				FoodDao foodDao = new FoodDaoImpl();
				int foodId = Integer.parseInt(req.getParameter("foodId"));
				try 
				{
					Food food = foodDao.getFoodByID(foodId);
					RequestDispatcher rd = req.getRequestDispatcher("Details.jsp");
					req.setAttribute("food", food);
					rd.forward(req, resp);
				} 
				catch (FoodNotFoundException e) 
				{					
					e.printStackTrace();				
				}
			}
			
			if(operation!=null && operation.equals("showImage"))
			{
				resp.setContentType("image/jpg");
				
				
				System.out.println(req.getParameter("foodName"));
				System.out.println(FoodsServlet.class.getResourceAsStream("../../../../Resources/"+ req.getParameter("foodName") +".jpeg"));
				InputStream i = FoodsServlet.class.getResourceAsStream("../../../../Resources/"+ req.getParameter("foodName") +".jpeg");
				ServletOutputStream o = resp.getOutputStream();
				
				int c = i.read();
				
				
				while(c!=-1)
				{
					o.write(c);
					c = i.read();
					
				}
				
				i.close();
				o.flush();
				o.close();
			}
			
		}
		else
		{
			PrintWriter out = resp.getWriter();
			out.print("Please Login First <a href=Login.jsp>Login</a> ");
		}
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		resp.setContentType("text/html");
		RequestDispatcher rd;
		FoodDao foodDao;
		List<Food> listOfFoods;
		String operation = req.getParameter("operation");
		System.out.println("operation"+operation);
		if(operation!=null && operation.equals("getFoodByType"))
		{
			System.out.println("in get food by ");
			String foodType=req.getParameter("foodType");
			System.out.println("food type"+foodType);
			foodDao = new FoodDaoImpl();
			listOfFoods  = foodDao.searchFoodsByType(foodType);
			req.setAttribute("listOfFoods", listOfFoods);
			rd = req.getRequestDispatcher("Foods.jsp");
			rd.forward(req, resp);
		}
	}

	@Override
	public void destroy() 
	{
	}
}
