package in.squadinfotech.foodplaza.dao;

import java.util.List;

import in.squadinfotech.foodplaza.exception.FoodNotFoundException;
import in.squadinfotech.foodplaza.dto.Food;

public interface FoodDao
{
	boolean addFood(Food food);
	List<Food> getAllFoods();
	Food getFoodByID(int foodID)throws FoodNotFoundException;
	boolean deleteFood(int foodID)throws FoodNotFoundException ;
	boolean updateByID(int foodID)throws FoodNotFoundException;
	boolean updateByFood(Food food)throws FoodNotFoundException;
	List<Food> searchFoodsByType(String foodType);
	
}
