package in.squadinfotech.foodplaza.dto;

public class User
{
	private String userName;
	private String password;
	private long mobileNo;
	private String emailID;
	private boolean admin;
	private String gender;
	private Address officeAddress;
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public boolean isAdmin() {
		return admin;
	}
	public void setAdmin(boolean admin) {
		this.admin = admin;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Address getOfficeAddress() {
		return officeAddress;
	}
	public void setOfficeAddress(Address officeAddress) {
		this.officeAddress = officeAddress;
	}
	@Override
	public String toString() {
		return "\nUser [userName=" + userName + ", password=" + password
				+ ", mobileNo=" + mobileNo + ", emailID=" + emailID
				+ ", admin=" + admin + ", officeAddress=" + officeAddress + "]";
	}
	
}
