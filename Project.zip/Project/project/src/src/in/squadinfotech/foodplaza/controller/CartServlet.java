package in.squadinfotech.foodplaza.controller;

import in.squadinfotech.foodplaza.dao.FoodDao;
import in.squadinfotech.foodplaza.dao.jdbc.impl.FoodDaoImpl;
import in.squadinfotech.foodplaza.dto.Cart;
import in.squadinfotech.foodplaza.dto.Food;
import in.squadinfotech.foodplaza.exception.FoodNotFoundException;

import java.io.IOException;
import java.io.PrintWriter;
//import java.util.Enumeration;
//import java.util.Iterator;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class CartServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;


	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException
	{
		Cart cart = null;
		PrintWriter out = resp.getWriter();
		HttpSession s = req.getSession(false);

		if(s!=null)
		{

			RequestDispatcher rd = req.getRequestDispatcher(resp.encodeRedirectURL("foods?operation=getAllFoods"));

			FoodDao dao = new FoodDaoImpl();
			String operation = req.getParameter("operation");
			System.out.println(operation+" khgkfjhgkfjghf");

			if(operation!=null && operation.equals("addToCart"))
			{
				
				int foodId = Integer.parseInt(req.getParameter("foodId"));

				try 
				{
					Food food = dao.getFoodByID(foodId);
					if(s.getAttribute("cart") == null)
					{
						cart = new Cart();
					}
					else
					{
						cart = (Cart) s.getAttribute("cart");
					}

					System.out.println(cart.addToCart(food));
					s.setAttribute("cart", cart);
					
					rd.forward(req, resp);
				} 
				catch (FoodNotFoundException e) 
				{					
					e.printStackTrace();
				}
			}
			else if(operation!=null && operation.equals("removeFromCart"))
			{

				int foodId = Integer.parseInt(req.getParameter("foodId"));

				try 
				{
					Food food = dao.getFoodByID(foodId);
					if( s.getAttribute("cart") == null)
					{
	
						cart = new Cart();
					}
					else
					{
						cart = (Cart) s.getAttribute("cart");
					}

					cart.removeFromCart(food);
					s.setAttribute("cart", cart);
					//resp.sendRedirect("Cart.jsp");
					rd=req.getRequestDispatcher(resp.encodeRedirectURL("cart?operation=showCart"));
					//out.println("Food Removed");
					rd.include(req, resp);
				} 
				catch (FoodNotFoundException e) 
				{					
					e.printStackTrace();
				}




			}
			else if(operation!=null && operation.equals("showCart"))
			{
				

				cart= (Cart) s.getAttribute("cart");
				if(cart!=null)
				{
					Set<Food> set= cart.getFoodCart();
					if(set==null || set.size()==0)
					{
						out.println("<h1> Cart is Empty </h1>");
						out.println("<a href="+resp.encodeURL("foods")+">Continue shopping...</a>");
					}
					else
					{
						s.setAttribute("set", set);
						rd=req.getRequestDispatcher("Cart.jsp");
						rd.include(req, resp);
						//resp.sendRedirect("Cart.jsp");
					}
				}
				else 
				{
					out.println("<h1> Cart is Empty </h1>");
					out.println("<a href="+resp.encodeURL("foods")+">Continue shopping...</a>");
				}
				
			}


		}
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException 
	{
	}
}
