package in.squadinfotech.foodplaza.dto;

import java.io.Serializable;

public class Food implements Comparable<Food>, Cloneable, Serializable
{
	private int foodID;
	private String foodName;
	private int foodPrice;
	private int foodQuantity;
	private FoodType foodtype;
	
	public Food() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getFoodID() {
		return foodID;
	}
	public void setFoodID(int foodID) {
		this.foodID = foodID;
	}
	
	public int getFoodPrice() {
		return foodPrice;
	}
	public void setFoodPrice(int foodPrice) {
		this.foodPrice = foodPrice;
	}
	public String getFoodName() {
		return foodName;
	}
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	public int getFoodQuantity() {
		return foodQuantity;
	}
	public void setFoodQuantity(int foodQuantity) {
		this.foodQuantity = foodQuantity;
	}	
	public FoodType getFoodtype() {
		return foodtype;
	}
	public void setFoodtype(FoodType foodtype) {
		this.foodtype = foodtype;
	}
	
	
	
	@Override
	public String toString() {
		return "Food [foodID=" + foodID + ", foodName=" + foodName
				+ ", foodPrice=" + foodPrice + ", foodQuantity=" + foodQuantity
				+ ", foodtype=" + foodtype + "]";
	}
	@Override
	public int hashCode() 
	{		
		return foodID;
	}
	
	@Override
	public boolean equals(Object obj) 
	{
		if(obj instanceof Food)
		{
			Food f=(Food)obj;
			
			if(this.foodID==f.foodID)
				return true;
		}
		return false;
	}
	@Override
	public int compareTo(Food food) {
		
		return this.getFoodID()-food.getFoodID() ;
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
}
