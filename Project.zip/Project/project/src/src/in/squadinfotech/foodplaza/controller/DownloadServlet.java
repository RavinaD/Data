package in.squadinfotech.foodplaza.controller;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/download")
public class DownloadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("application/pdf");
		String fileName = "html.pdf";
		InputStream i = DownloadServlet.class.getResourceAsStream("../../../../../Resources/html.pdf");
		response.setContentLength(i.available());
		System.out.println(i.available());
		response.setHeader("Content-Disposition", "attachment; filename="+fileName); 
		ServletOutputStream o = response.getOutputStream();
		
		byte [] b = new byte[20000];
		int c = i.read(b);
		
		while(c > 0)
		{
			o.write(b);
			c = i.read(b);
		}
		
		i.close();
		o.flush();
		o.close();
	}
}
