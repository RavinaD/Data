package in.squadinfotech.foodplaza.controller;

import in.squadinfotech.foodplaza.dao.UserDao;
import in.squadinfotech.foodplaza.dao.jdbc.impl.UserDaoImpl;
import in.squadinfotech.foodplaza.dto.Address;
import in.squadinfotech.foodplaza.dto.Cart;
import in.squadinfotech.foodplaza.dto.User;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class UserServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	@Override
	public void init() throws ServletException {
		
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException 
	{
		System.out.println("In doGet");
		String operation = req.getParameter("operation");
		HttpSession session = null;
		RequestDispatcher rd;
		PrintWriter out=resp.getWriter();
		
		if(operation!=null && operation.equals("editProfileUser"))
		{
			session = req.getSession(false);
			String userName=(String) session.getAttribute("uName");
			out.println("<h1> Welcome " + userName +"</h1>");
			rd = req.getRequestDispatcher("ChangePassword.jsp");	
			rd.include(req, resp);
		}
		else if (operation!=null && operation.equals("logOut")) {

			session = req.getSession(false);
			
			if(session!=null)
			{
				Cart c = (Cart) session.getAttribute("cart");
				c = null;
				session.invalidate();
				
			}
				rd=req.getRequestDispatcher("Login.jsp");	
				req.setAttribute("logout", "Logout");
				rd.forward(req,resp);
		
			
		}

		
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException 
	{
		System.out.println("in doPost");
		resp.setContentType("text/html");

		String operation = req.getParameter("operation");
		System.out.println(operation+"  ");
		HttpSession session = null;
		RequestDispatcher rd;
		PrintWriter out=resp.getWriter();

		if(operation!=null && operation.equals("loginUser"))
		{

			String userName=req.getParameter("userName");
			String password=req.getParameter("password");
			User user=new User();
			user.setUserName(userName);
			
			user.setPassword(password);	//user.setAdmin(Boolean.parseBoolean(admin));
			UserDao userDao=new UserDaoImpl();
			if(userDao.isUserExist(user))
			{/*
				if(user.isAdmin())
				{
					session=req.getSession();
					session.setAttribute("uName", userName);
					rd=req.getRequestDispatcher("foods?operation=getAllFoods");		
					rd.forward(req,resp);
				}
				else
				{*/
					session=req.getSession();
					session.setAttribute("uName", userName);
				/*	rd=req.getRequestDispatcher("foods?operation=getAllFoods");		
					rd.forward(req,resp);*/
					resp.sendRedirect(resp.encodeRedirectURL("foods?operation=getAllFoods"));

			}
			else
			{
				
				rd=req.getRequestDispatcher("Login.jsp");	
				req.setAttribute("error", "errrrrr");
				//out.println("<h3> <font color='red'> USERNAME or PASSWORD IS INCORRECT <font> </h3>");
				rd.include(req,resp);
			}
		}

		else if(operation!=null && operation.equals("registerUser"))
		{
			
			session = req.getSession(false);
			//fetch request parameters
			String userName=req.getParameter("userName");
			String password=req.getParameter("password");
			String admin=req.getParameter("admin");
			String gender=req.getParameter("gender");
			String phonenumber=req.getParameter("phonenumber");
			String emailID=req.getParameter("emailID");
			String city=req.getParameter("city");
			String pincode=req.getParameter("pincode");
			
			User user=new User();
			user.setUserName(userName);
			user.setPassword(password);
		
			if(admin!=null && admin.equals("on"))
				user.setAdmin(true);
			else
				user.setAdmin(false);
			user.setEmailID(emailID);
			user.setMobileNo(Long.parseLong(phonenumber));
			user.setGender(gender);
			Address add=new Address();
			add.setCity(city);
			add.setPinCode(Integer.parseInt(pincode));
			user.setOfficeAddress(add);
			UserDao userDao=new UserDaoImpl();
			if(userDao.addUser(user))
			{
			
				rd=req.getRequestDispatcher("Login.jsp");	
				req.setAttribute("success", "errrrrrooorrr");
				rd.include(req,resp);
			}
			else
			{
				rd=req.getRequestDispatcher("Registration.jsp");
				req.setAttribute("errorregister", "errrrrrooorrr");
				rd.include(req,resp);
			}
		}

		else if(operation!=null && operation.equals("editProfileUser"))
		{
			System.out.println("IN editProfileUser");
			session = req.getSession(false);
			System.out.println(session.getId());
			String oldpassword = req.getParameter("password");
			String newpassword = req.getParameter("newpassword");
			String confirmpassword = req.getParameter("confirmpassword");
			if(confirmpassword.equals(newpassword))
			{
				System.out.println("Ok");
				
				UserDao dao = new UserDaoImpl();	
	
				User user = new User();
				user.setUserName((String) session.getAttribute("uName"));
				user.setPassword(oldpassword);
				if(dao.isUserExist(user))
				{
					dao.changePassword((String) session.getAttribute("uName"), oldpassword, newpassword);
					rd=req.getRequestDispatcher("Foods.jsp");	
					//req.setAttribute("pass", "Password");
					out.println("<h3>Password has been changed sucessfully.......</h3>");
					rd.include(req,resp);
					//out.println("<h1> Welcome " + (String) session.getAttribute("uName") +"</h1>");
				}
			}
			else
			{
				rd=req.getRequestDispatcher("ChangePassword.jsp");	
				out.println("<h3> <font color='red'> newpassword & confirmpassword should be same......<font> </h3>");
				rd.include(req,resp);
			}
		}
	}
}
