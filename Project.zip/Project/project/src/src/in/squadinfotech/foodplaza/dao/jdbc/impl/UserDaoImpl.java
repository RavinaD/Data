package in.squadinfotech.foodplaza.dao.jdbc.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import in.squadinfotech.foodplaza.dao.DBConstant;
import in.squadinfotech.foodplaza.dao.UserDao;
import in.squadinfotech.foodplaza.dto.Address;
import in.squadinfotech.foodplaza.dto.User;
import in.squadinfotech.foodplaza.exception.UserNotFoundException;

public class UserDaoImpl implements UserDao, DBConstant {
 User user=new User();
	@Override
	public boolean addUser(User user) {
		Connection con=DBUtil.getConnection();
		int noOfRowsUpdated=0;
		try {
			PreparedStatement pstmt=con.prepareStatement(DBConstant.INSERT_USER);
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			pstmt.setLong(3, user.getMobileNo());
			pstmt.setString(4, user.getEmailID());
			pstmt.setBoolean(5, user.isAdmin());
			pstmt.setString(6, user.getOfficeAddress().getCity());
			pstmt.setInt(7, user.getOfficeAddress().getPinCode());
			pstmt.setString(8, user.getGender());
			noOfRowsUpdated = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return noOfRowsUpdated==1;
		
	}

	@Override
	public List<User> getAllUsers() {
		List<User> listOfUsers=new ArrayList<User>();
		ResultSet rs=null;
		try {
			PreparedStatement pstmt=DBUtil.getConnection().prepareStatement(DBConstant.SELECT_ALL_USER);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				User user=new User();
				Address officeAddress=new Address();
				user.setUserName(rs.getString(1));
				user.setPassword(rs.getString(2));
				user.setMobileNo(rs.getLong(3));
				user.setEmailID(rs.getString(4));
				user.setAdmin(rs.getBoolean(5));
				officeAddress.setCity(rs.getString(6));
				officeAddress.setPinCode(rs.getInt(7));
				user.setOfficeAddress(officeAddress);
				listOfUsers.add(user);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listOfUsers;
		
	}

	@Override
	public User getByUserName(String userName) throws UserNotFoundException 
	{
		User user=null;
		
		ResultSet rs=null;
		try {
			PreparedStatement pstmt=DBUtil.getConnection().prepareStatement(DBConstant.GET_USER);
			pstmt.setString(1, userName);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				user=new User();
				Address officeAddress=new Address();
				user.setUserName(rs.getString(1));
				user.setPassword(rs.getString(2));
				user.setMobileNo(rs.getLong(3));
				user.setEmailID(rs.getString(4));
				user.setAdmin(rs.getBoolean(5));
				officeAddress.setCity(rs.getString(6));
				officeAddress.setPinCode(rs.getInt(7));
				user.setOfficeAddress(officeAddress);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}

	@Override
	public boolean deleteUser(String userName) {
		int noOfRowsUpdated=0;
		try {	
			PreparedStatement pstmt=DBUtil.getConnection().prepareStatement(DBConstant.DELETE_USER);
			pstmt.setString(1,userName);
			noOfRowsUpdated = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return noOfRowsUpdated==1;
		
	}

	@Override
	public boolean updateUser(User user) 
	{
		int noOfRowsUpdated=0;
		try {
			PreparedStatement pstmt=DBUtil.getConnection().prepareStatement(DBConstant.UPDATE_USER_BY_NAME);
			pstmt.setString(7, user.getUserName());
			pstmt.setString(1, user.getPassword());
			pstmt.setLong(2, user.getMobileNo());
			pstmt.setString(3, 	user.getEmailID());
			pstmt.setBoolean(4, user.isAdmin());
			pstmt.setString(5, user.getOfficeAddress().getCity());
			pstmt.setInt(6, user.getOfficeAddress().getPinCode());
			
			noOfRowsUpdated = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return noOfRowsUpdated==1;
		
	
	}

	@Override
	public boolean changePassword(String userName, String oldPassword, String newPassword) 
	{
		System.out.println(user.getUserName()+"  "+user.getPassword());
		int noOfRowsUpdated=0;
		try {
			if(oldPassword.equals(getByUserName(userName).getPassword()))
			{
				PreparedStatement pstmt=DBUtil.getConnection().prepareStatement(DBConstant.CHANGE_PASSWORD);
				pstmt.setString(1, newPassword );
				pstmt.setString(2, userName);
				noOfRowsUpdated=pstmt.executeUpdate();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UserNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return noOfRowsUpdated==1;
	}

	@Override
	public boolean isUserExist(User user)
	{
		PreparedStatement pstmt;
		
		System.out.println(user.getUserName());
		System.out.println(user.getPassword());
		try 
		{
			pstmt = DBUtil.getConnection().prepareStatement(DBConstant.USER_EXIST);
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			ResultSet rs=pstmt.executeQuery();
			if(rs.next())
			{
				return true;
			}
			
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;

	}

	
}
