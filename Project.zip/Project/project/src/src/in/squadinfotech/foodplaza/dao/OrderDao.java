package in.squadinfotech.foodplaza.dao;

public interface OrderDao 
{

}
