package in.squadinfotech.foodplaza.controller;

import in.squadinfotech.foodplaza.dto.Cart;
import in.squadinfotech.foodplaza.dto.Food;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class OrderServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException 
	{
		Cart cart = null;
		PrintWriter out = resp.getWriter();
		HttpSession s = req.getSession(false);
		RequestDispatcher rd;
		if(s!=null)
		{			
			String operation = req.getParameter("operation");
			
			 if(operation!=null && operation.equals("showOrder"))
				{
					
					cart= (Cart) s.getAttribute("cart");
					if(cart!=null)
					{
						Set<Food> set= cart.getFoodCart();
						if(set==null || set.size()==0)
						{
							out.println("<h1> Cart is Empty </h1>");
						}
						else
						{
							s.setAttribute("set1", set);
							rd=req.getRequestDispatcher("Order1.jsp");
							rd.include(req, resp);
							//resp.sendRedirect("Cart.jsp");
						}
					}
					else 
					{
						out.println("<h1> Cart is Empty </h1>");
					}
					out.println("<a href="+resp.encodeURL("foods")+">Continue shopping...</a>");
				}
			
			
		}
	}
}
