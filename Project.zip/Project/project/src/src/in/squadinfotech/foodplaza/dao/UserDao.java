package in.squadinfotech.foodplaza.dao;

import java.util.List;

import in.squadinfotech.foodplaza.dto.User;
import in.squadinfotech.foodplaza.exception.UserNotFoundException;

public interface UserDao 
{
	boolean addUser(User user);
	List<User> getAllUsers();
	User getByUserName(String userName)throws UserNotFoundException;
	boolean deleteUser(String userName);
	boolean updateUser(User user);
	boolean changePassword(String userName, String oldPassword, String newPassword);
	boolean isUserExist(User user);
}
