package in.squadinfotech.foodplaza.dao.jdbc.impl;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil 
{
	static private Connection con=createConnection();
	
	private DBUtil(){}
	
	private static Connection createConnection() 
	{
		Properties p=new Properties();
		try {
			p.load(DBUtil.class.getResourceAsStream("/Resources/Database.Properties"));
			Class.forName(p.getProperty("driverClassName"));
			con=DriverManager.getConnection(p.getProperty("url"), p.getProperty("username"), p.getProperty("password"));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
	}
	
	public static Connection getConnection()
	{
		return con;
	}
	
	public static void close() 
	{
		try {
			if(con!=null)
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}
