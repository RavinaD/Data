package in.squadinfotech.foodplaza.controller;
   
import in.squadinfotech.foodplaza.dao.UserDao;
import in.squadinfotech.foodplaza.dao.jdbc.impl.UserDaoImpl;
import in.squadinfotech.foodplaza.dto.User;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public void init() throws ServletException {
//		System.out.println("In init()");
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		System.out.println("In Protocol service");
		resp.setContentType("text/html");
		RequestDispatcher rd=null;
		PrintWriter out = resp.getWriter();
		HttpSession session=req.getSession();
		
		String userName = req.getParameter("userName");
		String password = req.getParameter("password");
		User user=new User();
		user.setUserName(userName);
		user.setPassword(password);		
		UserDao userdao= new UserDaoImpl();
		if(userdao.isUserExist(user))
		{
			out.println("Welcome to login servlet");
			rd=req.getRequestDispatcher("foods");
			rd.include(req, resp);
			//rd.forward(req, resp);
		}
		else
			out.println("<h1>Username or Password is Incorrect</h1>");
		out.close();
	}
	
	@Override
	public void destroy() {
//		System.out.println("In destroy()");
	}
}
