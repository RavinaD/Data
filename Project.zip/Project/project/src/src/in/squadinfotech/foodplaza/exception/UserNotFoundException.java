package in.squadinfotech.foodplaza.exception;

public class UserNotFoundException extends Exception 
{
	String userName;

	public UserNotFoundException(String userName) 
	{
		this.userName = userName;
	}

	@Override
	public String toString() 
	{
		return "UserNotFoundException [userName=" + userName + "]";
	}
	
}
