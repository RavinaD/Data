package in.squadinfotech.foodplaza.dao.jdbc.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import in.squadinfotech.foodplaza.dao.DBConstant;
import in.squadinfotech.foodplaza.dao.FoodDao;
import in.squadinfotech.foodplaza.dto.Food;
import in.squadinfotech.foodplaza.dto.FoodType;
import in.squadinfotech.foodplaza.exception.FoodNotFoundException;

public class FoodDaoImpl implements FoodDao, DBConstant
{
	@Override
	public boolean addFood(Food food) 
	{
		Connection con=DBUtil.getConnection();
		int noOfRowsUpdated=0;
		try {
			PreparedStatement pstmt=con.prepareStatement(DBConstant.INSERT_FOOD);
			pstmt.setInt(1, food.getFoodID());
			pstmt.setString(2, food.getFoodName());
			pstmt.setInt(3, food.getFoodPrice());
			pstmt.setInt(4, food.getFoodQuantity());
			pstmt.setInt(5, food.getFoodtype().getFoodTypeID());
			pstmt.setString(6, food.getFoodtype().getFoodTypeName());
			noOfRowsUpdated = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return noOfRowsUpdated==1;
	}

	@Override
	public List<Food> getAllFoods() 
	{
		List<Food> listOfFoods=new ArrayList<Food>();
		ResultSet rs=null;
		try {
			PreparedStatement pstmt=DBUtil.getConnection().prepareStatement(DBConstant.SELECT_ALL_FOODS);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				Food food=new Food();
				FoodType foodtype=new FoodType();
				food.setFoodID(rs.getInt(1));
				food.setFoodName(rs.getString(2));
				foodtype.setFoodTypeName(rs.getString(3));
				food.setFoodPrice(rs.getInt(4));
				food.setFoodQuantity(rs.getInt(5));
				//foodtype.setFoodTypeID(rs.getInt(5));
				//foodtype.setFoodTypeName(rs.getString(3));
				food.setFoodtype(foodtype);
				listOfFoods.add(food);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listOfFoods;
	}

	@Override
	public Food getFoodByID(int foodID) throws FoodNotFoundException {

		Food food=new Food();
		FoodType foodtype=new FoodType();
		ResultSet rs=null;
		try {
			PreparedStatement pstmt=DBUtil.getConnection().prepareStatement(DBConstant.GET_FOOD);
			pstmt.setInt(1,foodID);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				food.setFoodID(rs.getInt(1));
				food.setFoodName(rs.getString(2));
				foodtype.setFoodTypeName(rs.getString(3));
				food.setFoodPrice(rs.getInt(4));
				food.setFoodQuantity(rs.getInt(5));
				food.setFoodtype(foodtype);

				return food;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		throw new FoodNotFoundException(foodID);

	}

	@Override
	public boolean deleteFood(int foodID) throws FoodNotFoundException {

		int noOfRowsUpdated=0;
		try {
			PreparedStatement pstmt=DBUtil.getConnection().prepareStatement(DBConstant.DELETE_FOOD);
			pstmt.setInt(1,foodID);
			noOfRowsUpdated = pstmt.executeUpdate();
			if(noOfRowsUpdated==1)
				return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		throw new FoodNotFoundException(foodID);
	}

	@Override
	public boolean updateByID(int foodID) throws FoodNotFoundException {
		int noOfRowsUpdated=0;
		try {
			PreparedStatement pstmt=DBUtil.getConnection().prepareStatement(DBConstant.UPDATE_FOOD_BYID);
			pstmt.setInt(1, foodID);

			noOfRowsUpdated = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return noOfRowsUpdated==1;

	}

	@Override
	public List<Food> searchFoodsByType(String foodType) {
		List<Food> listOfFoods=new ArrayList<Food>();
		ResultSet rs=null;
		try {
			PreparedStatement pstmt=DBUtil.getConnection().prepareStatement(SEARCH_FOOD_BY_TYPE);
			pstmt.setString(1,foodType);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				Food food=new Food();
				FoodType foodType1=new FoodType();
				food.setFoodID(rs.getInt(1));
				food.setFoodName(rs.getString(2));
				foodType1.setFoodTypeName((rs.getString(3)));
				food.setFoodPrice(rs.getInt(4));
				food.setFoodQuantity(rs.getInt(5));
				food.setFoodtype(foodType1);
				listOfFoods.add(food);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listOfFoods;	
	}

	@Override
	public boolean updateByFood(Food food) throws FoodNotFoundException {
		int noOfRowsUpdated=0;
		try {
			PreparedStatement pstmt=DBUtil.getConnection().prepareStatement(DBConstant.UPDATE_FOOD);
			pstmt.setInt(5, food.getFoodID());
			pstmt.setString(1, food.getFoodName());
			//pstmt.setString(2, food.getFoodType());
			pstmt.setInt(3, food.getFoodPrice());
			pstmt.setInt(4, food.getFoodQuantity());
			noOfRowsUpdated = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return noOfRowsUpdated==1;

	}

}
