package in.squadinfotech.foodplaza.controller;

import in.squadinfotech.foodplaza.dao.UserDao;
import in.squadinfotech.foodplaza.dao.jdbc.impl.UserDaoImpl;
import in.squadinfotech.foodplaza.dto.Address;
import in.squadinfotech.foodplaza.dto.User;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet("/Registration")
public class RegistrationServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
   
	public void init()throws ServletException
	{
		System.out.println();
	}	
	
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		System.out.println("in doPost");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		String admin=request.getParameter("admin");
		String gender=request.getParameter("gender");
		String phonenumber=request.getParameter("phonenumber");
		String emailID=request.getParameter("emailID");
		String city=request.getParameter("city");
		String pincode=request.getParameter("pincode");
		
		User user=new User();
		user.setUserName(userName);
		user.setPassword(password);
		user.setAdmin(Boolean.parseBoolean(admin));
		user.setEmailID(emailID);
		user.setMobileNo(Long.parseLong(phonenumber));
		user.setGender(gender);
		Address add=new Address();
		add.setCity(city);
		add.setPinCode(Integer.parseInt(pincode));
		user.setOfficeAddress(add);
		
		UserDao userdao= new UserDaoImpl();
		if(userdao.addUser(user))
		{
			response.sendRedirect("Login.html");
		}
		 
		out.close();
	}

	public void destroy() {
		
	}

}
