package in.squadinfotech.foodplaza.dto;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class Cart 
{
	private Food f;
	private Set<Food> foodCart;
	public Cart()
	{
		foodCart=new TreeSet<Food>();
	}
	public boolean addToCart(Food food)
	{
		//Food f=null;
		try {
			f = (Food) food.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(foodCart.contains(food))
		{
			Iterator<Food> i=foodCart.iterator();

			while(i.hasNext())
			{
				f=i.next();
				if(f.getFoodID()==food.getFoodID())
				{
					f.setFoodQuantity(f.getFoodQuantity()+1);
				}
			}
			return false;
		}
		else
		{
			f.setFoodQuantity(1);
			foodCart.add(f);
			return true;
		}
	}
	public boolean removeFromCart(Food food)
	{

		if (foodCart.contains(food))
		{
			Iterator<Food> i = foodCart.iterator();

			while (i.hasNext()) 
			{
				Food food1 = i.next();
				if(food1.getFoodID() == food.getFoodID())
				{
					if (food1.getFoodQuantity() > 1)
					{
						food1.setFoodQuantity(food1.getFoodQuantity() - 1);
					} 
					else if(food1.getFoodQuantity()==1)
					{
						i.remove();
					}
					break;
				}
			}
		}
		System.out.println(foodCart);
		return true;

	}
	public Set<Food> getFoodCart() {
		return foodCart;
	}

	public Food getFoodbyId(int foodID)
	{
		Iterator<Food> i=foodCart.iterator();
		while(i.hasNext())
		{
			Food f=i.next();
			if(f.getFoodID()==foodID)
				return f;

		}
		return f;

	}



}

