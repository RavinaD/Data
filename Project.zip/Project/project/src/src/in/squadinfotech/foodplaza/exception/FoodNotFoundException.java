package in.squadinfotech.foodplaza.exception;

public class FoodNotFoundException extends Exception
{
	int foodID;
	
	public FoodNotFoundException(int foodID) 
	{
		super();
		this.foodID = foodID;
	}

	@Override
	public String toString() {
		return "FoodNotFoundException [foodID=" + foodID + "]";
	}
	
 
}
