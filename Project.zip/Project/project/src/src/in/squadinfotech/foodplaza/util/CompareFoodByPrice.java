package in.squadinfotech.foodplaza.util;

import in.squadinfotech.foodplaza.dto.Food;

import java.util.Comparator;

public class CompareFoodByPrice implements Comparator<Food>
{
	public int compare(Food f1, Food f2)
	{		
		return f1.getFoodPrice()-f2.getFoodPrice();
	}
}
